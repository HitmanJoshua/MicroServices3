package com.assignment1.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
public class Payments {
	
	private long txnId;
	private String customerName;
	private double txnAmount;

}
