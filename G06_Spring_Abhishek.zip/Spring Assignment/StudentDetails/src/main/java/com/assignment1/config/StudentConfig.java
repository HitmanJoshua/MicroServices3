package com.assignment1.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import com.assignment1.model.Payments;
import com.assignment1.model.Student;



@Configuration 
@EnableWebMvc  
@ComponentScan(basePackages="com.assignment1.controllers") 
public class StudentConfig implements WebMvcConfigurer {
	
	
	@Bean
	public InternalResourceViewResolver resolver() { // for resolving the view(init()=> index)
		
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		
		resolver.setPrefix("/WEB-INF/Views/"); // add path
		resolver.setSuffix(".jsp"); // add extension
		
		resolver.setViewClass(JstlView.class);
		
		return resolver;
	}
	
	@Bean
	public Student Ramesh() {
		
		return new Student();
	}
	
	@Bean
	public ModelAndView mdlView() {
		
		return new ModelAndView();
	}
	
	@Bean
	public RestTemplate template() {
		
		return new RestTemplate();
	}

	@Bean
	public Payments payments() {
		
		return new Payments();
	}
	
}
