package com.assignment1.model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class Student {
	
	private long studentId;
	private String studentName;
	private String section;
	private String fatherName;
	private String address;

}


