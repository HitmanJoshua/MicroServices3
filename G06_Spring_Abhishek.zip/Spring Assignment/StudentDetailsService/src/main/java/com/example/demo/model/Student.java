package com.example.demo.model;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name="student_details")
public class Student {
	
	@Id
	private long studentId;
	private String studentName;
	private String section;
	private String fatherName;
	private String address;

}


