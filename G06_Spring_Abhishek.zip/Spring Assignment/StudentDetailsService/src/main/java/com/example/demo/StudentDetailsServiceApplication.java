package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.model.Student;
import com.example.demo.services.StudentService;

@SpringBootApplication
public class StudentDetailsServiceApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(StudentDetailsServiceApplication.class, args);
		
		
		StudentService service  = ctx.getBean(StudentService.class);
		
		Student std1 = new Student();
		
		std1.setStudentId(101);
		std1.setStudentName("Arul");
		std1.setSection("A");
		std1.setFatherName("Arul marban");
		std1.setAddress("Chennai");
		service.save(std1);
	}

}
