package com.example.demo.controllers;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;
import com.example.demo.services.StudentService;



@RestController
public class StudentServiceController {
	
	@Autowired
	private StudentService service;
	
	@PostMapping(value = "/addStudent", produces="application/json" , consumes="application/json")
	public Student add(@RequestBody Student entity) {
		
		return this.service.save(entity);
	}
	
	@GetMapping(value = "/viewStudents")
	public List<Student> getAll() {
		//
		List<Student> pmtList = new ArrayList<>();
		
		this.service.findAll().forEach(eachObject -> {
			pmtList.add(eachObject);
		});
		
		return pmtList;
	}
	
	@GetMapping(value = "/viewStudent/{id}")
	public Student getAll(@PathVariable long id) {	
		
		
		return this.service.findById(id);
	}
	
	@GetMapping(value = "/delete/{id}")
	public String deleteById(@PathVariable long id) throws IllegalArgumentException{			
		
		this.service.deleteById(id);
		return "deleted";
	}
	
//	@GetMapping(value="/payments/get")
//	public Student get() {
//		
//		return this.service.get();
//	}
	
	

}
