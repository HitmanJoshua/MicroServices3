package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Student;
import com.example.demo.repo.StudentRepository;



@Service
public class StudentService {
	
	@Autowired
	private StudentRepository repo;
	
//	@Autowired
//	private PaymentRepo payRepo;
	
	
	public Student save(Student entity) {
		
		return repo.save(entity);
	}
	
	
	public Iterable<Student> findAll() {
		
		return repo.findAll();
	}
	
	public Student findById(long id) {
		
		return repo.findById(id).get();
	}
	
	public void deleteById(long id) throws IllegalArgumentException{
		
		repo.deleteById(id);
	}
	
//	public Student get() {
//		
//		return payRepo.findUser();
//	}

}
